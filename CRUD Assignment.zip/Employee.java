public class Employee {
    private int eid;
    private String ename;
    private int salary;

    public Employee(int eid,String ename,int salary){
        this.eid =eid;
        this.ename=ename;
        this.salary=salary;
    }

    public void seteid(int eid){
        this.eid=eid;
    }
    
    public void setename(String ename){
        this.ename=ename;
    }

    public void setsalary(int salary){
        this.salary=salary;
    }

    public int geteid(){
        return eid;
    }

    public String getename(){
        return ename;
    }

    public int getsalary(){
        return salary;
    }

    public String toString(){
        return eid+" "+ename+" "+salary;
    }

}   
