import java.util.Scanner;

public class Main {
    static Scanner sc=new Scanner(System.in);
    static Employeeser eser= new Employeeser();
    static void ch(){
    System.out.println("************************");        
    System.out.println("1. Create");
    System.out.println("2. Update");
    System.out.println("3. Search");
    System.out.println("4. Delete");
    System.out.println("5. Display");   
    System.out.println("Enter your choice");
    int ch= sc.nextInt();     
    }

}

static void UserChoice(int ch){
    switch(ch){
        case 1:
            System.out.print("Enter the ID no : ");
            int id = sc.nextInt();
            System.out.print("Enter the name : ");
            String ename= sc.next();
            System.out.print("Enter the salary : ");
            int salary =sc.nextInt();
            Employee newlist[] = eser.CreateEmployee(new Employee(id, ename, salary));
            for (int i =0;i<newlist.length;i++){
                System.our.println(newlist[i]);
            }
            UserChoice();
        break;
        case 2:
            System.our.println("Enter the id no to update : ");
            int uid=sc.nextInt();
            
    }
}
