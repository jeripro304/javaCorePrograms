

public class Employeeser{
    Employee elist[]=new Employee[15];

    public void CreateEmployeeList(){
        for(int i=0;i<elist.length;i<8;i++){
            elist[i]=new Employee((10+(i+1)),ename+(i+1),sal 100000+(i+1));
        }
    }

    public Employee check(int eid){
        

    }
}